import { useState } from "react";
import { motion } from "motion/react";
import {
  MapPin,
  Calendar,
  Clock,
  Zap,
  User,
  Phone,
  Mail,
  Car,
  CheckCircle2,
} from "lucide-react";

export function Booking() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    station: "",
    date: "",
    time: "",
    chargingType: "",
    name: "",
    phone: "",
    email: "",
    vehicle: "",
  });

  const stations = [
    { id: 1, name: "Green Valley Station - Sector 62, Noida" },
    { id: 2, name: "City Center Hub - Connaught Place, Delhi" },
    { id: 3, name: "Tech Park Station - Cyber City, Gurgaon" },
    { id: 4, name: "Suburban Charge Point - Dwarka, Delhi" },
    { id: 5, name: "Airport Express Station - Aerocity, Delhi" },
  ];

  const chargingTypes = [
    {
      type: "fast",
      name: "Fast Charging (150 kW)",
      duration: "30-45 min",
      price: "₹500",
    },
    {
      type: "ultra",
      name: "Ultra Fast Charging (250 kW)",
      duration: "20-30 min",
      price: "₹700",
    },
    {
      type: "normal",
      name: "Normal Charging (50 kW)",
      duration: "2-3 hours",
      price: "₹300",
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      setStep(4);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  if (step === 4) {
    return (
      <div className="min-h-screen bg-secondary/30 flex items-center justify-center py-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl mx-auto px-4"
        >
          <div className="bg-white rounded-3xl p-8 md:p-12 text-center shadow-xl">
            <div className="w-20 h-20 bg-accent rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl md:text-4xl mb-4">Booking Confirmed!</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Your charging slot has been successfully reserved
            </p>
            <div className="bg-secondary/50 rounded-2xl p-6 mb-8 text-left">
              <h3 className="text-lg mb-4">Booking Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Station:</span>
                  <span>{stations.find((s) => s.id.toString() === formData.station)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date:</span>
                  <span>{formData.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Time:</span>
                  <span>{formData.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Charging Type:</span>
                  <span>
                    {chargingTypes.find((t) => t.type === formData.chargingType)?.name}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-3 mt-3">
                  <span className="text-lg">Total Amount:</span>
                  <span className="text-lg text-accent">
                    {chargingTypes.find((t) => t.type === formData.chargingType)?.price}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-sm text-muted-foreground mb-6">
              A confirmation email has been sent to {formData.email}
            </div>
            <button
              onClick={() => {
                setStep(1);
                setFormData({
                  station: "",
                  date: "",
                  time: "",
                  chargingType: "",
                  name: "",
                  phone: "",
                  email: "",
                  vehicle: "",
                });
              }}
              className="px-8 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all"
            >
              Make Another Booking
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-gradient-to-br from-accent to-green-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-4xl md:text-5xl mb-4">Book Your Charging Slot</h1>
            <p className="text-xl opacity-90">Reserve your spot in just a few steps</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-center mb-12">
          <div className="flex items-center gap-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    step >= s
                      ? "bg-accent text-white"
                      : "bg-white border-2 border-border text-muted-foreground"
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-16 h-1 ${
                      step > s ? "bg-accent" : "bg-border"
                    } transition-all`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-lg">
          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-2xl mb-6">Select Station & Schedule</h2>
                <div className="space-y-6">
                  <div>
                    <label className="flex items-center gap-2 mb-3">
                      <MapPin className="w-5 h-5 text-accent" />
                      Select Station
                    </label>
                    <select
                      required
                      value={formData.station}
                      onChange={(e) => handleInputChange("station", e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    >
                      <option value="">Choose a station</option>
                      {stations.map((station) => (
                        <option key={station.id} value={station.id}>
                          {station.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="flex items-center gap-2 mb-3">
                        <Calendar className="w-5 h-5 text-accent" />
                        Select Date
                      </label>
                      <input
                        type="date"
                        required
                        value={formData.date}
                        onChange={(e) => handleInputChange("date", e.target.value)}
                        min={new Date().toISOString().split("T")[0]}
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>

                    <div>
                      <label className="flex items-center gap-2 mb-3">
                        <Clock className="w-5 h-5 text-accent" />
                        Select Time
                      </label>
                      <input
                        type="time"
                        required
                        value={formData.time}
                        onChange={(e) => handleInputChange("time", e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-2xl mb-6">Choose Charging Type</h2>
                <div className="space-y-4">
                  {chargingTypes.map((type) => (
                    <label
                      key={type.type}
                      className={`block p-6 rounded-xl border-2 cursor-pointer transition-all ${
                        formData.chargingType === type.type
                          ? "border-accent bg-accent/5"
                          : "border-border hover:border-accent/50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="chargingType"
                        value={type.type}
                        checked={formData.chargingType === type.type}
                        onChange={(e) => handleInputChange("chargingType", e.target.value)}
                        className="hidden"
                      />
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                            <Zap className="w-6 h-6 text-accent" />
                          </div>
                          <div>
                            <div className="text-lg mb-1">{type.name}</div>
                            <div className="text-sm text-muted-foreground">
                              Duration: {type.duration}
                            </div>
                          </div>
                        </div>
                        <div className="text-2xl text-accent">{type.price}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-2xl mb-6">Personal Information</h2>
                <div className="space-y-6">
                  <div>
                    <label className="flex items-center gap-2 mb-3">
                      <User className="w-5 h-5 text-accent" />
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      placeholder="Enter your full name"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="flex items-center gap-2 mb-3">
                        <Phone className="w-5 h-5 text-accent" />
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+91 XXXXX XXXXX"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>

                    <div>
                      <label className="flex items-center gap-2 mb-3">
                        <Mail className="w-5 h-5 text-accent" />
                        Email Address
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="your@email.com"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-2 mb-3">
                      <Car className="w-5 h-5 text-accent" />
                      Vehicle Model
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.vehicle}
                      onChange={(e) => handleInputChange("vehicle", e.target.value)}
                      placeholder="e.g., Tata Nexon EV, Tesla Model 3"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            <div className="flex gap-4 mt-8">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="px-8 py-4 border border-border rounded-xl hover:bg-secondary/50 transition-all"
                >
                  Previous
                </button>
              )}
              <button
                type="submit"
                className="flex-1 px-8 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all"
              >
                {step === 3 ? "Confirm Booking" : "Continue"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
