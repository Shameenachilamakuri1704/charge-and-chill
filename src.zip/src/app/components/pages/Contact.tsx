import { useState } from "react";
import { motion } from "motion/react";
import {
  Mail,
  Phone,
  MapPin,
  Send,
  MessageSquare,
  Star,
  CheckCircle2,
} from "lucide-react";

export function Contact() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [rating, setRating] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => setFormSubmitted(false), 3000);
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      details: "+91 1800-CHARGE",
      subdetails: "Mon-Sun, 24/7 Support",
    },
    {
      icon: Mail,
      title: "Email",
      details: "support@chargeandchill.com",
      subdetails: "We reply within 24 hours",
    },
    {
      icon: MapPin,
      title: "Head Office",
      details: "Sector 62, Noida",
      subdetails: "Uttar Pradesh, India 201301",
    },
  ];

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-gradient-to-br from-accent to-green-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-4xl md:text-5xl mb-4">Get in Touch</h1>
            <p className="text-xl opacity-90 max-w-2xl">
              Have questions? We'd love to hear from you
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {contactInfo.map((info, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 border border-border text-center hover:shadow-lg transition-shadow"
            >
              <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <info.icon className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-lg mb-2">{info.title}</h3>
              <p className="text-foreground mb-1">{info.details}</p>
              <p className="text-sm text-muted-foreground">{info.subdetails}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl p-8 md:p-10 border border-border shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-accent" />
              </div>
              <h2 className="text-2xl">Send us a Message</h2>
            </div>

            {formSubmitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-12 h-12 text-accent" />
                </div>
                <h3 className="text-2xl mb-2">Message Sent!</h3>
                <p className="text-muted-foreground">
                  We'll get back to you within 24 hours
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block mb-2">Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Enter your name"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                  <div>
                    <label className="block mb-2">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block mb-2">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 XXXXX XXXXX"
                    className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>

                <div>
                  <label className="block mb-2">Subject</label>
                  <select
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="">Select a subject</option>
                    <option>General Inquiry</option>
                    <option>Technical Support</option>
                    <option>Membership Question</option>
                    <option>Station Availability</option>
                    <option>Billing Issue</option>
                    <option>Partnership Inquiry</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-2">Message</label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Tell us how we can help you..."
                    className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl p-8 md:p-10 border border-border shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                <Star className="w-6 h-6 text-accent" />
              </div>
              <h2 className="text-2xl">Share Your Feedback</h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block mb-3">Rate Your Experience</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-10 h-10 ${
                          star <= rating
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block mb-2">Station Visited</label>
                <select
                  required
                  className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option value="">Select station</option>
                  <option>Green Valley Station - Noida</option>
                  <option>City Center Hub - Delhi</option>
                  <option>Tech Park Station - Gurgaon</option>
                  <option>Suburban Charge Point - Dwarka</option>
                  <option>Airport Express - Aerocity</option>
                </select>
              </div>

              <div>
                <label className="block mb-2">Your Feedback</label>
                <textarea
                  required
                  rows={6}
                  placeholder="Share your experience with us..."
                  className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                />
              </div>

              <div>
                <label className="block mb-2">Name (Optional)</label>
                <input
                  type="text"
                  placeholder="Your name"
                  className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <button
                type="submit"
                className="w-full px-6 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all flex items-center justify-center gap-2"
              >
                <Star className="w-5 h-5" />
                Submit Feedback
              </button>
            </form>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 bg-white rounded-3xl p-8 border border-border"
        >
          <h2 className="text-2xl mb-6 text-center">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 rounded-xl bg-secondary/30">
              <h3 className="mb-2">What are your operating hours?</h3>
              <p className="text-sm text-muted-foreground">
                Our charging stations are open 24/7. Lounge facilities are available from 6 AM to
                11 PM daily.
              </p>
            </div>
            <div className="p-6 rounded-xl bg-secondary/30">
              <h3 className="mb-2">How do I become a member?</h3>
              <p className="text-sm text-muted-foreground">
                Visit our Services page to choose a membership plan, or sign up through your
                dashboard after creating an account.
              </p>
            </div>
            <div className="p-6 rounded-xl bg-secondary/30">
              <h3 className="mb-2">Can I cancel my booking?</h3>
              <p className="text-sm text-muted-foreground">
                Yes, you can cancel up to 2 hours before your scheduled time for a full refund.
              </p>
            </div>
            <div className="p-6 rounded-xl bg-secondary/30">
              <h3 className="mb-2">Do you offer corporate plans?</h3>
              <p className="text-sm text-muted-foreground">
                Yes! Contact us at corporate@chargeandchill.com for custom enterprise solutions
                and fleet charging packages.
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 bg-gradient-to-br from-accent to-green-600 text-white rounded-3xl p-12 text-center"
        >
          <h2 className="text-3xl mb-4">Need Immediate Assistance?</h2>
          <p className="text-lg opacity-90 mb-8">
            Our support team is available 24/7 to help you
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a
              href="tel:+911800CHARGE"
              className="px-8 py-4 bg-white text-accent rounded-xl hover:bg-gray-100 transition-all inline-flex items-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call Us Now
            </a>
            <a
              href="mailto:support@chargeandchill.com"
              className="px-8 py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all inline-flex items-center gap-2"
            >
              <Mail className="w-5 h-5" />
              Email Support
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
