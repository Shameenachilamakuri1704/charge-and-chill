import { useState } from "react";
import { motion } from "motion/react";
import {
  User,
  Settings,
  CreditCard,
  History,
  LogOut,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Zap,
  Calendar,
  MapPin,
  TrendingUp,
  Wallet,
  Download,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export function Dashboard() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  const bookingHistory = [
    {
      id: "BK001",
      station: "Green Valley Station",
      date: "2026-04-10",
      time: "14:30",
      amount: "₹500",
      status: "Completed",
    },
    {
      id: "BK002",
      station: "City Center Hub",
      date: "2026-04-05",
      time: "10:15",
      amount: "₹700",
      status: "Completed",
    },
    {
      id: "BK003",
      station: "Tech Park Station",
      date: "2026-03-28",
      time: "16:45",
      amount: "₹500",
      status: "Completed",
    },
    {
      id: "BK004",
      station: "Airport Express",
      date: "2026-03-20",
      time: "09:00",
      amount: "₹700",
      status: "Completed",
    },
  ];

  const usageData = [
    { month: "Jan", sessions: 4, amount: 2000 },
    { month: "Feb", sessions: 6, amount: 3200 },
    { month: "Mar", sessions: 5, amount: 2800 },
    { month: "Apr", sessions: 3, amount: 1900 },
  ];

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-secondary/30 flex items-center justify-center py-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md mx-auto px-4"
        >
          <div className="bg-white rounded-3xl p-8 md:p-10 shadow-xl">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl mb-2">
                {isSignUp ? "Create Account" : "Welcome Back"}
              </h2>
              <p className="text-muted-foreground">
                {isSignUp
                  ? "Sign up to start charging with us"
                  : "Sign in to access your dashboard"}
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-5">
              {isSignUp && (
                <div>
                  <label className="flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-accent" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your full name"
                    className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
              )}

              <div>
                <label className="flex items-center gap-2 mb-2">
                  <Mail className="w-4 h-4 text-accent" />
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 mb-2">
                  <Lock className="w-4 h-4 text-accent" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="Enter your password"
                    className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {!isSignUp && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    <span>Remember me</span>
                  </label>
                  <a href="#" className="text-accent hover:underline">
                    Forgot password?
                  </a>
                </div>
              )}

              <button
                type="submit"
                className="w-full px-6 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all"
              >
                {isSignUp ? "Create Account" : "Sign In"}
              </button>
            </form>

            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">
                {isSignUp ? "Already have an account? " : "Don't have an account? "}
              </span>
              <button
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-accent hover:underline"
              >
                {isSignUp ? "Sign In" : "Sign Up"}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-gradient-to-br from-accent to-green-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl mb-2">Dashboard</h1>
              <p className="text-lg opacity-90">Welcome back, Rahul!</p>
            </div>
            <button
              onClick={() => setIsLoggedIn(false)}
              className="flex items-center gap-2 px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl border border-border overflow-hidden sticky top-24">
              <div className="p-6 border-b border-border">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-accent rounded-full flex items-center justify-center text-white text-xl">
                    R
                  </div>
                  <div>
                    <div>Rahul Sharma</div>
                    <div className="text-sm text-muted-foreground">Premium Member</div>
                  </div>
                </div>
              </div>

              <nav className="p-4">
                {[
                  { id: "overview", label: "Overview", icon: TrendingUp },
                  { id: "history", label: "Booking History", icon: History },
                  { id: "wallet", label: "Wallet & Payments", icon: Wallet },
                  { id: "settings", label: "Profile Settings", icon: Settings },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all ${
                      activeTab === tab.id
                        ? "bg-accent text-white"
                        : "text-foreground hover:bg-secondary/50"
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          <div className="lg:col-span-3">
            {activeTab === "overview" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-2xl p-6 border border-border">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                        <Zap className="w-6 h-6 text-accent" />
                      </div>
                      <TrendingUp className="w-5 h-5 text-accent" />
                    </div>
                    <div className="text-3xl mb-1">18</div>
                    <div className="text-sm text-muted-foreground">Total Sessions</div>
                  </div>

                  <div className="bg-white rounded-2xl p-6 border border-border">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-accent" />
                      </div>
                      <TrendingUp className="w-5 h-5 text-accent" />
                    </div>
                    <div className="text-3xl mb-1">₹9,900</div>
                    <div className="text-sm text-muted-foreground">Total Spent</div>
                  </div>

                  <div className="bg-white rounded-2xl p-6 border border-border">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-accent" />
                      </div>
                    </div>
                    <div className="text-3xl mb-1">3</div>
                    <div className="text-sm text-muted-foreground">This Month</div>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 border border-border">
                  <h3 className="text-lg mb-4">Monthly Usage</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={usageData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" stroke="#888" />
                      <YAxis stroke="#888" />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="sessions"
                        stroke="#10b981"
                        strokeWidth={3}
                        dot={{ fill: "#10b981", r: 5 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white rounded-2xl p-6 border border-border">
                  <h3 className="text-lg mb-4">Spending Overview</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={usageData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" stroke="#888" />
                      <YAxis stroke="#888" />
                      <Tooltip />
                      <Bar dataKey="amount" fill="#10b981" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>
            )}

            {activeTab === "history" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-2xl border border-border overflow-hidden"
              >
                <div className="p-6 border-b border-border">
                  <h2 className="text-2xl">Booking History</h2>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-secondary/30">
                      <tr>
                        <th className="px-6 py-4 text-left">Booking ID</th>
                        <th className="px-6 py-4 text-left">Station</th>
                        <th className="px-6 py-4 text-left">Date & Time</th>
                        <th className="px-6 py-4 text-left">Amount</th>
                        <th className="px-6 py-4 text-left">Status</th>
                        <th className="px-6 py-4 text-left">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {bookingHistory.map((booking) => (
                        <tr key={booking.id} className="hover:bg-secondary/20">
                          <td className="px-6 py-4">{booking.id}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-accent" />
                              {booking.station}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div>{booking.date}</div>
                            <div className="text-sm text-muted-foreground">{booking.time}</div>
                          </td>
                          <td className="px-6 py-4 text-accent">{booking.amount}</td>
                          <td className="px-6 py-4">
                            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                              {booking.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <button className="text-accent hover:underline flex items-center gap-1">
                              <Download className="w-4 h-4" />
                              Invoice
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === "wallet" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-gradient-to-br from-accent to-green-600 text-white rounded-2xl p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <div className="text-sm opacity-80 mb-1">Wallet Balance</div>
                      <div className="text-4xl">₹1,250</div>
                    </div>
                    <Wallet className="w-12 h-12 opacity-80" />
                  </div>
                  <button className="px-6 py-3 bg-white text-accent rounded-xl hover:bg-gray-100 transition-all">
                    Add Money
                  </button>
                </div>

                <div className="bg-white rounded-2xl p-6 border border-border">
                  <h3 className="text-lg mb-4">Saved Payment Methods</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-xl">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-accent" />
                        </div>
                        <div>
                          <div>•••• •••• •••• 4242</div>
                          <div className="text-sm text-muted-foreground">Expires 12/26</div>
                        </div>
                      </div>
                      <button className="text-accent hover:underline">Remove</button>
                    </div>

                    <button className="w-full px-6 py-4 border-2 border-dashed border-border rounded-xl hover:border-accent hover:bg-accent/5 transition-all">
                      + Add New Payment Method
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "settings" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-2xl p-6 border border-border"
              >
                <h2 className="text-2xl mb-6">Profile Settings</h2>
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block mb-2">Full Name</label>
                      <input
                        type="text"
                        defaultValue="Rahul Sharma"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                    <div>
                      <label className="block mb-2">Email Address</label>
                      <input
                        type="email"
                        defaultValue="rahul.sharma@email.com"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block mb-2">Phone Number</label>
                      <input
                        type="tel"
                        defaultValue="+91 98765 43210"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                    <div>
                      <label className="block mb-2">Vehicle Model</label>
                      <input
                        type="text"
                        defaultValue="Tata Nexon EV"
                        className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block mb-2">Address</label>
                    <textarea
                      rows={3}
                      defaultValue="Sector 62, Noida, Uttar Pradesh 201301"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-8 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all"
                  >
                    Save Changes
                  </button>
                </form>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
