import { Link } from "react-router";
import { motion } from "motion/react";
import {
  Zap,
  Coffee,
  Wifi,
  MapPin,
  Calendar,
  Battery,
  TrendingUp,
  Users,
  ChevronRight,
} from "lucide-react";
import { ImageWithFallback } from "../ImageWithFallback";

export function Home() {
  const features = [
    {
      icon: Zap,
      title: "Fast EV Charging",
      description: "Quick and efficient charging stations for all electric vehicles",
    },
    {
      icon: Coffee,
      title: "Comfortable Lounge",
      description: "Relax in our premium lounge with café and entertainment",
    },
    {
      icon: Wifi,
      title: "Free WiFi",
      description: "High-speed internet for work or entertainment while you wait",
    },
  ];

  const steps = [
    {
      icon: MapPin,
      title: "Find Nearby Station",
      description: "Locate charging stations near you with real-time availability",
    },
    {
      icon: Calendar,
      title: "Book a Time Slot",
      description: "Reserve your preferred time slot in advance",
    },
    {
      icon: Battery,
      title: "Charge & Relax",
      description: "Enjoy our premium amenities while your vehicle charges",
    },
  ];

  const testimonials = [
    {
      name: "Rahul Sharma",
      role: "Regular Customer",
      content:
        "Amazing experience! The lounge is so comfortable and the charging is super fast. Best decision switching to EV.",
    },
    {
      name: "Priya Patel",
      role: "Business Professional",
      content:
        "I use the co-working space regularly. It's perfect for working while my car charges. Very productive!",
    },
    {
      name: "Amit Kumar",
      role: "EV Enthusiast",
      content:
        "The premium membership is worth every penny. Great facilities and excellent service every time.",
    },
  ];

  const faqs = [
    {
      question: "How long does charging take?",
      answer:
        "Fast charging takes 30-45 minutes for 80% charge. Normal charging takes 2-3 hours for full charge.",
    },
    {
      question: "What amenities are included?",
      answer:
        "Free WiFi, café, co-working space, entertainment zone, and comfortable seating areas.",
    },
    {
      question: "Do I need membership?",
      answer:
        "No, membership is optional. We offer pay-per-use options, but memberships provide better value for frequent users.",
    },
    {
      question: "Which vehicles are supported?",
      answer:
        "We support all major EV brands including Tesla, Tata Nexon EV, MG ZS EV, Hyundai Kona, and more.",
    },
  ];

  return (
    <div>
      <section className="relative min-h-[calc(100vh-4rem)] flex items-center overflow-hidden bg-gradient-to-br from-white via-green-50 to-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-block px-4 py-2 bg-accent/10 rounded-full mb-6">
                <span className="text-accent">Eco-Friendly • Premium • Relaxing</span>
              </div>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl mb-6 leading-tight">
                Charge your vehicle.
                <br />
                <span className="text-accent">Chill your mind.</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-xl">
                Premium EV charging stations combined with comfortable lounges, cafés, and
                co-working spaces. Convert waiting time into a relaxing experience.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/stations"
                  className="px-8 py-4 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all shadow-lg hover:shadow-xl inline-flex items-center gap-2"
                >
                  Find Station
                  <ChevronRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/booking"
                  className="px-8 py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
                >
                  Book Now
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="rounded-3xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1760538961281-b4619503cc1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                  alt="Woman using EV charging station"
                  className="w-full h-[500px] object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                    <Zap className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <div className="text-2xl">50+</div>
                    <div className="text-sm text-muted-foreground">Charging Stations</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Why Choose Us</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the perfect blend of technology and comfort
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-8 rounded-2xl bg-gradient-to-br from-white to-green-50 border border-border hover:shadow-lg transition-shadow"
              >
                <div className="w-14 h-14 bg-accent rounded-xl flex items-center justify-center mb-6">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-secondary/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground">Simple steps to get started</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative text-center"
              >
                <div className="inline-flex items-center justify-center w-20 h-20 bg-accent text-white rounded-full mb-6 text-2xl">
                  {index + 1}
                </div>
                <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center mx-auto mb-6 shadow-md">
                  <step.icon className="w-7 h-7 text-accent" />
                </div>
                <h3 className="text-xl mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-border -translate-x-1/2" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Business & Revenue Model</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Sustainable and profitable business built on multiple revenue streams
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Primary Revenue</div>
              <h3 className="text-xl mb-2">Charging Fees</h3>
              <p className="text-muted-foreground mb-4">₹200 - ₹500 per session based on charging speed and duration</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Secondary Revenue</div>
              <h3 className="text-xl mb-2">Lounge Services</h3>
              <p className="text-muted-foreground mb-4">Café, co-working space rentals, and premium amenities</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Recurring Revenue</div>
              <h3 className="text-xl mb-2">Memberships</h3>
              <p className="text-muted-foreground mb-4">Monthly/annual premium plans for frequent users</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Additional Revenue</div>
              <h3 className="text-xl mb-2">F&B Sales</h3>
              <p className="text-muted-foreground mb-4">Café and beverage sales to customers</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Partnership Revenue</div>
              <h3 className="text-xl mb-2">Advertising</h3>
              <p className="text-muted-foreground mb-4">Strategic partnerships and in-station advertising</p>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border">
              <div className="text-accent mb-2">Future Revenue</div>
              <h3 className="text-xl mb-2">Value Services</h3>
              <p className="text-muted-foreground mb-4">Battery health monitoring, vehicle servicing partnerships</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-accent to-green-600 rounded-3xl p-8 md:p-12 text-white">
            <h3 className="text-3xl mb-8 text-center">Estimated Monthly Profit</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b border-white/20">
                    <span>Daily Users</span>
                    <span className="text-xl">50-100</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b border-white/20">
                    <span>Avg Revenue per User</span>
                    <span className="text-xl">₹300</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b border-white/20">
                    <span>Daily Revenue</span>
                    <span className="text-xl">₹15,000 - ₹30,000</span>
                  </div>
                  <div className="flex justify-between items-center pt-3">
                    <span className="text-xl">Monthly Revenue</span>
                    <span className="text-2xl">₹4.5L - ₹9L</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="w-20 h-20 mx-auto mb-4 opacity-80" />
                  <div className="text-5xl mb-2">₹6.75L</div>
                  <div className="text-xl opacity-90">Average Monthly Revenue</div>
                  <div className="text-sm opacity-75 mt-2">Based on 75 daily users</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-secondary/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Future Development</h2>
            <p className="text-xl text-muted-foreground">Building the future of EV charging</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">Mobile App Integration</h3>
              <p className="text-muted-foreground">
                iOS and Android apps for seamless booking, payments, and real-time updates
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">Real-time Availability Tracking</h3>
              <p className="text-muted-foreground">
                Live updates on station availability and estimated wait times
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">AI-based Recommendations</h3>
              <p className="text-muted-foreground">
                Smart suggestions for optimal charging times and nearby stations
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">Battery Health Monitoring</h3>
              <p className="text-muted-foreground">
                Advanced diagnostics and health reports for your EV battery
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">Subscription Plans</h3>
              <p className="text-muted-foreground">
                Flexible monthly and annual plans with unlimited charging benefits
              </p>
            </div>
            <div className="p-6 rounded-2xl bg-white border border-border">
              <h3 className="text-xl mb-3">Multi-city Expansion</h3>
              <p className="text-muted-foreground">
                Partner stations across major cities for nationwide coverage
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">What Our Customers Say</h2>
            <p className="text-xl text-muted-foreground">Real experiences from real people</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-8 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center text-white text-xl">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <div>{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
                <p className="text-muted-foreground italic">"{testimonial.content}"</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-secondary/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="p-6 rounded-2xl bg-white border border-border"
              >
                <h3 className="text-lg mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-accent to-green-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90">
            Find a station near you and experience the future of EV charging
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link
              to="/stations"
              className="px-8 py-4 bg-white text-accent rounded-xl hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl inline-flex items-center gap-2"
            >
              Find Station
              <ChevronRight className="w-5 h-5" />
            </Link>
            <Link
              to="/services"
              className="px-8 py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
            >
              View Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
