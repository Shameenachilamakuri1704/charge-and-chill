import { Link } from "react-router";
import { motion } from "motion/react";
import {
  Zap,
  Coffee,
  Wifi,
  Laptop,
  Tv,
  Battery,
  Shield,
  Wrench,
  Check,
  Crown,
  Star,
} from "lucide-react";
import { ImageWithFallback } from "../ImageWithFallback";

export function Services() {
  const chargingServices = [
    {
      icon: Zap,
      title: "Fast Charging",
      description: "150 kW fast charging for quick power-ups in 30-45 minutes",
      price: "₹500/session",
    },
    {
      icon: Battery,
      title: "Ultra Fast Charging",
      description: "250 kW ultra-fast charging for premium vehicles",
      price: "₹700/session",
    },
    {
      icon: Shield,
      title: "Battery Health Check",
      description: "Free battery diagnostics and health monitoring",
      price: "Free with charging",
    },
    {
      icon: Wrench,
      title: "Emergency Support",
      description: "24/7 technical assistance and emergency charging",
      price: "₹200 (non-members)",
    },
  ];

  const loungeServices = [
    {
      icon: Coffee,
      title: "Premium Café",
      description: "Fresh coffee, snacks, and beverages while you wait",
      image: "https://images.unsplash.com/photo-1750124662229-47a8e16b8f14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      icon: Laptop,
      title: "Co-working Space",
      description: "Quiet workspace with high-speed WiFi and charging ports",
      image: "https://images.unsplash.com/photo-1774763332467-bc0db28c6cb7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      icon: Tv,
      title: "Entertainment Zone",
      description: "Streaming services, games, and magazines for relaxation",
      image: "https://images.unsplash.com/photo-1751151015850-ae5e0356bb15?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      icon: Wifi,
      title: "Free WiFi",
      description: "High-speed internet access throughout the facility",
      image: "https://images.unsplash.com/photo-1759722665606-3be48960d3a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
  ];

  const membershipPlans = [
    {
      name: "Basic",
      price: "₹999",
      period: "/month",
      features: [
        "5 charging sessions/month",
        "Standard charging speed",
        "Free WiFi access",
        "10% café discount",
        "Priority booking",
      ],
      color: "border-gray-300",
      icon: Star,
    },
    {
      name: "Premium",
      price: "₹2,499",
      period: "/month",
      features: [
        "Unlimited charging sessions",
        "Fast & Ultra-fast charging",
        "Free co-working space access",
        "25% café discount",
        "Priority support",
        "Battery health reports",
        "Guest passes (2/month)",
      ],
      color: "border-accent",
      popular: true,
      icon: Crown,
    },
    {
      name: "Annual Premium",
      price: "₹24,999",
      period: "/year",
      features: [
        "All Premium features",
        "Save ₹5,000/year",
        "Free lounge upgrades",
        "50% café discount",
        "Exclusive events access",
        "Partner station network",
        "Dedicated support line",
      ],
      color: "border-primary",
      icon: Crown,
    },
  ];

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-gradient-to-br from-accent to-green-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-4xl md:text-5xl mb-4">Our Services</h1>
            <p className="text-xl opacity-90 max-w-2xl">
              Premium EV charging combined with world-class amenities
            </p>
          </motion.div>
        </div>
      </div>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">EV Charging Services</h2>
            <p className="text-xl text-muted-foreground">
              Fast, reliable, and convenient charging for all electric vehicles
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {chargingServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-border hover:shadow-lg transition-shadow"
              >
                <div className="w-14 h-14 bg-accent rounded-xl flex items-center justify-center mb-4">
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg mb-2">{service.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                <div className="text-accent">{service.price}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-secondary/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Lounge Amenities</h2>
            <p className="text-xl text-muted-foreground">
              Relax and unwind while your vehicle charges
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {loungeServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden border border-border hover:shadow-lg transition-shadow"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                      <service.icon className="w-5 h-5 text-accent" />
                    </div>
                    <h3 className="text-xl">{service.title}</h3>
                  </div>
                  <p className="text-muted-foreground">{service.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Membership Plans</h2>
            <p className="text-xl text-muted-foreground">
              Choose the perfect plan for your charging needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {membershipPlans.map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative p-8 rounded-3xl border-2 ${plan.color} ${
                  plan.popular ? "bg-gradient-to-br from-green-50 to-white shadow-xl scale-105" : "bg-white"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-accent text-white rounded-full text-sm">
                    Most Popular
                  </div>
                )}
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <plan.icon className="w-8 h-8 text-accent" />
                  </div>
                  <h3 className="text-2xl mb-2">{plan.name}</h3>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to="/booking"
                  className={`block w-full px-6 py-4 rounded-xl text-center transition-all ${
                    plan.popular
                      ? "bg-accent text-white hover:bg-accent/90 shadow-lg"
                      : "border-2 border-border hover:border-accent hover:bg-accent/5"
                  }`}
                >
                  Get Started
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-accent to-green-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl mb-6">Ready to Experience Premium Charging?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of satisfied EV owners who trust Charge & Chill
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link
              to="/booking"
              className="px-8 py-4 bg-white text-accent rounded-xl hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl"
            >
              Book Your First Session
            </Link>
            <Link
              to="/stations"
              className="px-8 py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
            >
              Find Nearby Stations
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
