import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import {
  MapPin,
  Navigation,
  Filter,
  Zap,
  Clock,
  Star,
  ChevronRight,
} from "lucide-react";

export function Stations() {
  const [filterDistance, setFilterDistance] = useState("all");
  const [filterAvailability, setFilterAvailability] = useState("all");
  const [filterType, setFilterType] = useState("all");

  const stations = [
    {
      id: 1,
      name: "Green Valley Station",
      location: "Sector 62, Noida",
      distance: "2.3 km",
      availability: "Available",
      chargingSpeed: "Fast (150 kW)",
      slots: "3/5 Available",
      amenities: ["Café", "WiFi", "Lounge"],
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1765272088009-100c96a4cd4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      id: 2,
      name: "City Center Hub",
      location: "Connaught Place, Delhi",
      distance: "5.1 km",
      availability: "Available",
      chargingSpeed: "Ultra Fast (250 kW)",
      slots: "2/4 Available",
      amenities: ["Café", "WiFi", "Co-working"],
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1768906730401-596a5156aa11?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      id: 3,
      name: "Tech Park Station",
      location: "Cyber City, Gurgaon",
      distance: "7.8 km",
      availability: "Busy",
      chargingSpeed: "Fast (150 kW)",
      slots: "1/6 Available",
      amenities: ["Café", "WiFi", "Lounge", "Co-working"],
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1768310465625-5824a01fff4c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      id: 4,
      name: "Suburban Charge Point",
      location: "Dwarka, Delhi",
      distance: "12.5 km",
      availability: "Available",
      chargingSpeed: "Normal (50 kW)",
      slots: "4/5 Available",
      amenities: ["WiFi", "Lounge"],
      rating: 4.5,
      image: "https://images.unsplash.com/photo-1760538978585-f82dc257ec15?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      id: 5,
      name: "Airport Express Station",
      location: "Aerocity, Delhi",
      distance: "15.2 km",
      availability: "Available",
      chargingSpeed: "Ultra Fast (250 kW)",
      slots: "5/8 Available",
      amenities: ["Café", "WiFi", "Lounge", "Entertainment"],
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1765272088009-100c96a4cd4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
    {
      id: 6,
      name: "Mall Plaza Station",
      location: "Saket, Delhi",
      distance: "8.3 km",
      availability: "Available",
      chargingSpeed: "Fast (150 kW)",
      slots: "3/6 Available",
      amenities: ["Café", "WiFi", "Entertainment"],
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1760538961281-b4619503cc1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    },
  ];

  const filteredStations = stations.filter((station) => {
    if (filterAvailability !== "all" && station.availability.toLowerCase() !== filterAvailability) {
      return false;
    }
    if (filterType !== "all") {
      const speedMatch = filterType === "fast" ? station.chargingSpeed.includes("Fast") : !station.chargingSpeed.includes("Fast");
      if (!speedMatch) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-secondary/30">
      <div className="bg-gradient-to-br from-accent to-green-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl mb-4">Find Charging Stations</h1>
            <p className="text-xl opacity-90 max-w-2xl">
              Locate nearby charging stations with real-time availability
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-6 border border-border sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-accent" />
                <h2 className="text-xl">Filters</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block mb-3">Distance</label>
                  <select
                    value={filterDistance}
                    onChange={(e) => setFilterDistance(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="all">All Distances</option>
                    <option value="5">Within 5 km</option>
                    <option value="10">Within 10 km</option>
                    <option value="20">Within 20 km</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-3">Availability</label>
                  <select
                    value={filterAvailability}
                    onChange={(e) => setFilterAvailability(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="all">All Stations</option>
                    <option value="available">Available Only</option>
                    <option value="busy">Busy Only</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-3">Charging Type</label>
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-secondary/30 focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="all">All Types</option>
                    <option value="fast">Fast Charging</option>
                    <option value="normal">Normal Charging</option>
                  </select>
                </div>

                <button className="w-full px-6 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all flex items-center justify-center gap-2">
                  <Navigation className="w-5 h-5" />
                  Use My Location
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-6 border border-border mb-6">
              <div className="aspect-video bg-gradient-to-br from-green-100 to-blue-100 rounded-xl flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-accent rounded-full" />
                  <div className="absolute top-1/2 left-1/3 w-3 h-3 bg-accent rounded-full" />
                  <div className="absolute top-1/3 left-2/3 w-3 h-3 bg-accent rounded-full" />
                  <div className="absolute top-2/3 left-1/2 w-3 h-3 bg-accent rounded-full" />
                  <div className="absolute top-1/2 left-3/4 w-3 h-3 bg-red-500 rounded-full" />
                </div>
                <div className="text-center z-10">
                  <MapPin className="w-16 h-16 text-accent mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground">Interactive Map View</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    {filteredStations.length} stations found nearby
                  </p>
                </div>
              </div>
            </div>

            <div className="mb-4">
              <h2 className="text-2xl">
                {filteredStations.length} Stations Available
              </h2>
            </div>

            <div className="space-y-4">
              {filteredStations.map((station, index) => (
                <motion.div
                  key={station.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="md:col-span-1">
                      <img
                        src={station.image}
                        alt={station.name}
                        className="w-full h-full object-cover min-h-[200px]"
                      />
                    </div>
                    <div className="md:col-span-2 p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl mb-1">{station.name}</h3>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <MapPin className="w-4 h-4" />
                            <span>{station.location}</span>
                            <span className="text-accent">• {station.distance}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span>{station.rating}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              station.availability === "Available"
                                ? "bg-accent"
                                : "bg-red-500"
                            }`}
                          />
                          <span className="text-sm">{station.availability}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{station.slots}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-accent" />
                          <span className="text-sm">{station.chargingSpeed}</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {station.amenities.map((amenity, i) => (
                          <span
                            key={i}
                            className="px-3 py-1 bg-accent/10 text-accent text-sm rounded-full"
                          >
                            {amenity}
                          </span>
                        ))}
                      </div>

                      <div className="flex gap-3">
                        <Link
                          to={`/booking?station=${station.id}`}
                          className="flex-1 px-6 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 transition-all text-center inline-flex items-center justify-center gap-2"
                        >
                          Book Now
                          <ChevronRight className="w-4 h-4" />
                        </Link>
                        <button className="px-6 py-3 border border-border rounded-xl hover:bg-secondary/50 transition-all">
                          Details
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
