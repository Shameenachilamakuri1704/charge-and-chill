import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/pages/Home";
import { Stations } from "./components/pages/Stations";
import { Booking } from "./components/pages/Booking";
import { Services } from "./components/pages/Services";
import { Dashboard } from "./components/pages/Dashboard";
import { Contact } from "./components/pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "stations", Component: Stations },
      { path: "booking", Component: Booking },
      { path: "services", Component: Services },
      { path: "dashboard", Component: Dashboard },
      { path: "contact", Component: Contact },
    ],
  },
]);
